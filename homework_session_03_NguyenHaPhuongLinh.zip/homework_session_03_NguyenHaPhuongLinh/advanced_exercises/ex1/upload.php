<?php

$uploadDir = "uploads/";
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    if (!isset($_FILES["avatar"]) || $_FILES["avatar"]["error"] !== UPLOAD_ERR_OK) {
        $message = "File upload error.";
    } else {

        $file = $_FILES["avatar"];


        $maxSize = 2 * 1024 * 1024; 
        if ($file["size"] > $maxSize) {
            $message = "File too large. Maximum size is 2MB.";
        } else {

            $allowedTypes = [
                "image/jpeg" => "jpg",
                "image/png"  => "png"
            ];

            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mimeType = $finfo->file($file["tmp_name"]);

            if (!array_key_exists($mimeType, $allowedTypes)) {
                $message = "Invalid file type. Only JPG and PNG allowed.";
            } else {

                $extension = $allowedTypes[$mimeType];
                $newFileName = bin2hex(random_bytes(16)) . "." . $extension;

                $destination = $uploadDir . $newFileName;

                if (move_uploaded_file($file["tmp_name"], $destination)) {
                    $message = "Upload successful!";
                } else {
                    $message = "Failed to save file.";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Secure Avatar Upload</title>
</head>
<body>

<h2>Upload Avatar</h2>

<form method="POST" enctype="multipart/form-data">
    <input type="file" name="avatar" accept=".jpg,.jpeg,.png" required>
    <button type="submit">Upload</button>
</form>

<p><?php echo htmlspecialchars($message); ?></p>

</body>
</html>