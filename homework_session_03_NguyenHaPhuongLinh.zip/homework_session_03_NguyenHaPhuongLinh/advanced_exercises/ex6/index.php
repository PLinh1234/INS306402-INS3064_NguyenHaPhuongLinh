<?php


$routes = [
    'home'    => 'home.php',
    'about'   => 'about.php',
    'contact' => 'contact.php'
];


$page = $_GET['page'] ?? 'home';
$page = strtolower(trim($page));


if (array_key_exists($page, $routes)) {
    $view = __DIR__ . '/views/' . $routes[$page];
} else {
    http_response_code(404);
    $view = __DIR__ . '/views/404.php';
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Simple Router</title>
</head>
<body>

<nav>
    <a href="?page=home">Home</a> |
    <a href="?page=about">About</a> |
    <a href="?page=contact">Contact</a>
</nav>

<hr>

<?php require $view; ?>

</body>
</html>