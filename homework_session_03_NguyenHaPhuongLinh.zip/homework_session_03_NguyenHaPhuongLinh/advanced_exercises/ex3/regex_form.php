<?php
$message = "";
$errors = [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $password = $_POST["password"] ?? "";


    if (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters long.";
    }


    if (!preg_match('/[A-Z]/', $password)) {
        $errors[] = "Missing at least 1 uppercase letter.";
    }


    if (!preg_match('/[a-z]/', $password)) {
        $errors[] = "Missing at least 1 lowercase letter.";
    }


    if (!preg_match('/[0-9]/', $password)) {
        $errors[] = "Missing at least 1 number.";
    }


    if (!preg_match('/[\W_]/', $password)) {
        $errors[] = "Missing at least 1 special character.";
    }

    if (empty($errors)) {
        $message = "Password is valid and meets all complexity requirements.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Regex Password Validation</title>
</head>
<body>

<h2>Create Password</h2>

<form method="POST">
    <input type="password" name="password" placeholder="Enter password" required>
    <button type="submit">Validate</button>
</form>

<?php if (!empty($errors)): ?>
    <div style="color:red;">
        <ul>
            <?php foreach ($errors as $error): ?>
                <li><?php echo htmlspecialchars($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<?php if (!empty($message)): ?>
    <p style="color:green;">
        <?php echo htmlspecialchars($message); ?>
    </p>
<?php endif; ?>

</body>
</html>