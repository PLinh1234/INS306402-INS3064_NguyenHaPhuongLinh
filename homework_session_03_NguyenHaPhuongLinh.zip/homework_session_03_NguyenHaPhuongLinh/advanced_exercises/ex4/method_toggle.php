<?php

$method = $_GET['method'] ?? 'GET';


$method = strtoupper($method);
if (!in_array($method, ['GET', 'POST'])) {
    $method = 'GET';
}

$data = [];
$requestType = $_SERVER['REQUEST_METHOD'];

if ($requestType === 'GET' && !empty($_GET) && isset($_GET['username'])) {
    $data = $_GET;
}

if ($requestType === 'POST' && !empty($_POST)) {
    $data = $_POST;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>GET vs POST Toggle</title>
</head>
<body>

<h2>Toggle Request Method</h2>

<!-- Toggle Links -->
<p>
    <a href="?method=GET">Use GET</a> |
    <a href="?method=POST">Use POST</a>
</p>

<h3>Current Form Method: <?php echo htmlspecialchars($method); ?></h3>

<form method="<?php echo htmlspecialchars($method); ?>">
    <input type="text" name="username" placeholder="Enter username" required>
    <input type="text" name="email" placeholder="Enter email" required>
    <button type="submit">Submit</button>
</form>

<hr>

<h3>Request Analysis</h3>

<p><strong>Detected REQUEST_METHOD:</strong>
    <?php echo htmlspecialchars($requestType); ?>
</p>

<h4>Superglobal Contents:</h4>

<pre>
<?php
if (!empty($data)) {
    print_r($data);
} else {
    echo "No data submitted yet.";
}
?>
</pre>

</body>
</html>