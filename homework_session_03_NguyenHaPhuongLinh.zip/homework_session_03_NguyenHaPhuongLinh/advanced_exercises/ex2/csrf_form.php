<?php
session_start();

function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

    
        setcookie(
            'csrf_token',
            $_SESSION['csrf_token'],
            [
                'expires' => time() + 3600,
                'path' => '/',
                'secure' => isset($_SERVER['HTTPS']), 
                'httponly' => false, 
                'samesite' => 'Strict'
            ]
        );
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken() {
    if (
        !isset($_POST['csrf_token']) ||
        !isset($_COOKIE['csrf_token']) ||
        !isset($_SESSION['csrf_token'])
    ) {
        return false;
    }

    
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        return false;
    }


    if (!hash_equals($_COOKIE['csrf_token'], $_POST['csrf_token'])) {
        return false;
    }

    return true;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!verifyCsrfToken()) {
        http_response_code(403);
        echo "403 Forbidden - Invalid CSRF token.";
        exit;
    }

    echo "Form submitted successfully and CSRF verified.";
    exit;
}

$token = generateCsrfToken();
?>

<!DOCTYPE html>
<html>
<head>
    <title>CSRF Protection - Double Submit Cookie</title>
</head>
<body>

<h2>Secure Form</h2>

<form method="POST">
    <input type="text" name="username" placeholder="Enter username" required>

    <!-- Hidden CSRF token -->
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($token); ?>">

    <button type="submit">Submit</button>
</form>

</body>
</html>