<?php
$errors = [];
$old = [
    'username' => '',
    'email' => '',
    'password' => ''
];

if ($_SERVER["REQUEST_METHOD"] === "POST") {


    $old['username'] = trim($_POST['username'] ?? '');
    $old['email'] = trim($_POST['email'] ?? '');
    $old['password'] = $_POST['password'] ?? '';


    if ($old['username'] === '') {
        $errors['username'] = "Username is required.";
    } elseif (strlen($old['username']) < 3) {
        $errors['username'] = "Username must be at least 3 characters.";
    }


    if ($old['email'] === '') {
        $errors['email'] = "Email is required.";
    } elseif (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Invalid email format.";
    }


    if ($old['password'] === '') {
        $errors['password'] = "Password is required.";
    } elseif (strlen($old['password']) < 8) {
        $errors['password'] = "Password must be at least 8 characters.";
    }


    if (empty($errors)) {
        echo "<h3 style='color:green;'>Form submitted successfully!</h3>";
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Error Summary Example</title>
    <style>
        .error-summary {
            background: #ffe6e6;
            border: 1px solid #cc0000;
            padding: 15px;
            margin-bottom: 20px;
        }
        .error-summary ul {
            margin: 0;
            padding-left: 20px;
        }
        .error-field {
            border: 2px solid red;
        }
        .field-error {
            color: red;
            font-size: 14px;
        }
    </style>
</head>
<body>

<h2>Registration Form</h2>

<?php if (!empty($errors)): ?>
    <div class="error-summary">
        <strong>Please fix the following errors:</strong>
        <ul>
            <?php foreach ($errors as $error): ?>
                <li><?php echo htmlspecialchars($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="POST">

    <div>
        <input
            type="text"
            name="username"
            placeholder="Username"
            value="<?php echo htmlspecialchars($old['username']); ?>"
            class="<?php echo isset($errors['username']) ? 'error-field' : ''; ?>"
        >
        <?php if (isset($errors['username'])): ?>
            <div class="field-error">
                <?php echo htmlspecialchars($errors['username']); ?>
            </div>
        <?php endif; ?>
    </div>

    <br>

    <div>
        <input
            type="text"
            name="email"
            placeholder="Email"
            value="<?php echo htmlspecialchars($old['email']); ?>"
            class="<?php echo isset($errors['email']) ? 'error-field' : ''; ?>"
        >
        <?php if (isset($errors['email'])): ?>
            <div class="field-error">
                <?php echo htmlspecialchars($errors['email']); ?>
            </div>
        <?php endif; ?>
    </div>

    <br>

    <div>
        <input
            type="password"
            name="password"
            placeholder="Password"
            class="<?php echo isset($errors['password']) ? 'error-field' : ''; ?>"
        >
        <?php if (isset($errors['password'])): ?>
            <div class="field-error">
                <?php echo htmlspecialchars($errors['password']); ?>
            </div>
        <?php endif; ?>
    </div>

    <br>

    <button type="submit">Register</button>

</form>

</body>
</html>