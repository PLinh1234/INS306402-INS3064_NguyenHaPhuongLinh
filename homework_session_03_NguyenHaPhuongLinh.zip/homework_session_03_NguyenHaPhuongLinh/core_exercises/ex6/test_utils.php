<?php
require_once "utils.php";

function assert_test(string $label, bool $condition)
{
    echo $label . ": ";
    echo $condition ? "PASS" : "FAIL";
    echo "<br>";
}

echo "<h2>Validation Library Tests</h2>";

assert_test("Required - not empty", is_required("hello") === true);
assert_test("Required - empty", is_required("") === false);

assert_test("Valid Email", is_valid_email("test@mail.com") === true);
assert_test("Invalid Email", is_valid_email("wrong-email") === false);

assert_test("Numeric Valid", is_numeric_value("123") === true);
assert_test("Numeric Invalid", is_numeric_value("abc") === false);

assert_test("Min Length Pass", min_length("hello", 3) === true);
assert_test("Min Length Fail", min_length("hi", 3) === false);

assert_test("Max Length Pass", max_length("hello", 10) === true);
assert_test("Max Length Fail", max_length("hello world", 5) === false);

$dirty = "<script>alert(1)</script>";
$clean = sanitize($dirty);
assert_test("Sanitize Works", $clean !== $dirty);