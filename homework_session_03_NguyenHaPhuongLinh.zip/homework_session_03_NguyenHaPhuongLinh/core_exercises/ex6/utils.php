<?php

function sanitize(string $value): string
{
    return htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
}

function is_required(string $value): bool
{
    return trim($value) !== "";
}

function is_valid_email(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function is_numeric_value($value): bool
{
    return is_numeric($value);
}

function min_length(string $value, int $length): bool
{
    return strlen(trim($value)) >= $length;
}

function max_length(string $value, int $length): bool
{
    return strlen(trim($value)) <= $length;
}