<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$name = "";
$email = "";
$age = "";
$errors = [];
$success = "";


if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name  = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $age   = trim($_POST["age"] ?? "");

    if ($name === "") {
        $errors["name"] = "Name is required.";
    }

    if ($email === "") {
        $errors["email"] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors["email"] = "Invalid email format.";
    }

    if ($age === "") {
        $errors["age"] = "Age is required.";
    } elseif (!is_numeric($age) || (int)$age <= 0) {
        $errors["age"] = "Age must be a positive number.";
    }

    if (empty($errors)) {
        $success = "Form submitted successfully!";
        $name = $email = $age = "";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sticky Form Example</title>
</head>
<body>

<h2>Sticky Form</h2>

<?php if ($success): ?>
    <p style="color:green;"><?php echo htmlspecialchars($success); ?></p>
<?php endif; ?>

<form method="POST">

    <label>Name:</label><br>
    <input type="text" name="name"
        value="<?php echo htmlspecialchars($name); ?>">
    <br>
    <span style="color:red;">
        <?php echo $errors["name"] ?? ""; ?>
    </span>
    <br><br>

    <label>Email:</label><br>
    <input type="text" name="email"
        value="<?php echo htmlspecialchars($email); ?>">
    <br>
    <span style="color:red;">
        <?php echo $errors["email"] ?? ""; ?>
    </span>
    <br><br>

    <label>Age:</label><br>
    <input type="text" name="age"
        value="<?php echo htmlspecialchars($age); ?>">
    <br>
    <span style="color:red;">
        <?php echo $errors["age"] ?? ""; ?>
    </span>
    <br><br>

    <input type="submit" value="Submit">
</form>

</body>
</html>