<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$result = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $num1 = $_POST["num1"] ?? "";
    $num2 = $_POST["num2"] ?? "";
    $operation = $_POST["operation"] ?? "";

    if (!is_numeric($num1) || !is_numeric($num2)) {
        $error = "Please enter valid numbers.";
    } else {

        $num1 = (float)$num1;
        $num2 = (float)$num2;

        switch ($operation) {
            case "add":
                $result = $num1 + $num2;
                break;

            case "subtract":
                $result = $num1 - $num2;
                break;

            case "multiply":
                $result = $num1 * $num2;
                break;

            case "divide":
                if ($num2 == 0) {
                    $error = "Cannot divide by zero.";
                } else {
                    $result = $num1 / $num2;
                }
                break;

            default:
                $error = "Invalid operation.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Arithmetic Calculator</title>
</head>
<body>

<h2>Arithmetic Calculator</h2>

<form method="POST">
    <label>Number 1:</label><br>
    <input type="text" name="num1"><br><br>

    <label>Number 2:</label><br>
    <input type="text" name="num2"><br><br>

    <label>Operation:</label><br>
    <select name="operation">
        <option value="add">Addition (+)</option>
        <option value="subtract">Subtraction (-)</option>
        <option value="multiply">Multiplication (*)</option>
        <option value="divide">Division (/)</option>
    </select><br><br>

    <input type="submit" value="Calculate">
</form>

<?php
if ($error != "") {
    echo "<p style='color:red;'>$error</p>";
}

if ($result !== "") {
    echo "<p>Result: <strong>$result</strong></p>";
}
?>

</body>
</html>