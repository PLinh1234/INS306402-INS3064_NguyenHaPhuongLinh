<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$query = "";

if (isset($_GET["q"])) {
    $query = trim($_GET["q"]);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Search Feature</title>
</head>
<body>

<h2>Search</h2>

<form method="GET">
    <input 
        type="text" 
        name="q" 
        placeholder="Enter keyword..."
        value="<?php echo htmlspecialchars($query); ?>"
    >
    <input type="submit" value="Search">
</form>

<?php if ($query !== ""): ?>
    <p>
        You searched for: 
        <strong><?php echo htmlspecialchars($query); ?></strong>
    </p>
<?php endif; ?>

</body>
</html>