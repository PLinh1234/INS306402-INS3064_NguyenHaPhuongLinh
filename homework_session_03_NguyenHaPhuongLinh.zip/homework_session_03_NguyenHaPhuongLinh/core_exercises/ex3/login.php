<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$correct_username = "admin";
$correct_password = "123456";

if (!isset($_SESSION["attempts"])) {
    $_SESSION["attempts"] = 0;
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = trim($_POST["username"] ?? "");
    $password = trim($_POST["password"] ?? "");

    if ($_SESSION["attempts"] >= 3) {
        $message = "Account locked. Too many failed attempts.";
    } else {

        if ($username === $correct_username && $password === $correct_password) {
            $message = "Login successful!";
            $_SESSION["attempts"] = 0; 
        } else {
            $_SESSION["attempts"]++;
            $remaining = 3 - $_SESSION["attempts"];
            $message = "Invalid credentials. Attempts left: $remaining";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login with Counter</title>
</head>
<body>

<h2>Login</h2>

<form method="POST">
    <label>Username:</label><br>
    <input type="text" name="username"><br><br>

    <label>Password:</label><br>
    <input type="password" name="password"><br><br>

    <input type="submit" value="Login">
</form>

<p>
<?php echo $message; ?>
</p>

<p>Failed Attempts: <?php echo $_SESSION["attempts"]; ?></p>

</body>
</html>