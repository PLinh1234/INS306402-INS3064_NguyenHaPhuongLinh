<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$name = "";
$email = "";
$errors = [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");

    if ($name === "") {
        $errors["name"] = "Name is required.";
    }

    if ($email === "") {
        $errors["email"] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors["email"] = "Invalid email format.";
    }

    if (empty($errors)) {
        header("Location: step2.php?name=" . urlencode($name) . "&email=" . urlencode($email));
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Step 1 - Basic Info</title>
</head>
<body>

<h2>Step 1: Basic Information</h2>

<form method="POST">

    <label>Name:</label><br>
    <input type="text" name="name"
        value="<?php echo htmlspecialchars($name); ?>">
    <br>
    <span style="color:red;"><?php echo $errors["name"] ?? ""; ?></span>
    <br><br>

    <label>Email:</label><br>
    <input type="text" name="email"
        value="<?php echo htmlspecialchars($email); ?>">
    <br>
    <span style="color:red;"><?php echo $errors["email"] ?? ""; ?></span>
    <br><br>

    <input type="submit" value="Next Step">
</form>

</body>
</html>