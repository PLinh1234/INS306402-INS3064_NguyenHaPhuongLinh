<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);


$name = trim($_GET["name"] ?? "");
$email = trim($_GET["email"] ?? "");

$age = "";
$password = "";
$errors = [];
$success = "";


if ($name === "" || $email === "") {
    header("Location: step1.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $age = trim($_POST["age"] ?? "");
    $password = trim($_POST["password"] ?? "");

    if ($age === "" || !is_numeric($age) || (int)$age <= 0) {
        $errors["age"] = "Valid age required.";
    }

    if (strlen($password) < 6) {
        $errors["password"] = "Password must be at least 6 characters.";
    }

    if (empty($errors)) {
        $success = "Registration Complete!<br>
                    Name: " . htmlspecialchars($name) . "<br>
                    Email: " . htmlspecialchars($email) . "<br>
                    Age: " . htmlspecialchars($age);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Step 2 - Additional Info</title>
</head>
<body>

<h2>Step 2: Additional Information</h2>

<?php if ($success): ?>
    <p style="color:green;"><?php echo $success; ?></p>
<?php else: ?>

<form method="POST">

    <!-- Hidden inputs to persist data -->
    <input type="hidden" name="name" value="<?php echo htmlspecialchars($name); ?>">
    <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">

    <p><strong>Name:</strong> <?php echo htmlspecialchars($name); ?></p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>

    <label>Age:</label><br>
    <input type="text" name="age" value="<?php echo htmlspecialchars($age); ?>">
    <br>
    <span style="color:red;"><?php echo $errors["age"] ?? ""; ?></span>
    <br><br>

    <label>Password:</label><br>
    <input type="password" name="password">
    <br>
    <span style="color:red;"><?php echo $errors["password"] ?? ""; ?></span>
    <br><br>

    <input type="submit" value="Complete Registration">
</form>

<?php endif; ?>

</body>
</html>