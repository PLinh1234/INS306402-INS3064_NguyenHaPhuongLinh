<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$name = "";
$email = "";
$message = "";
$errors = [];

// Handle POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $message = trim($_POST["message"] ?? "");

    // Validation
    if ($name === "") {
        $errors[] = "Name is required.";
    }

    if ($email === "") {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if ($message === "") {
        $errors[] = "Message is required.";
    }

    // If no errors → store success in session and redirect
    if (empty($errors)) {

        $_SESSION["success"] = "Thank you for contacting us!";
        $_SESSION["old"] = [
            "name" => $name,
            "email" => $email,
            "message" => $message
        ];

        header("Location: contact_self.php");
        exit;
    }
}

// After redirect (GET request)
$success = $_SESSION["success"] ?? "";
$old = $_SESSION["old"] ?? [];

unset($_SESSION["success"]);
unset($_SESSION["old"]);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Self Processing Contact Form</title>
</head>
<body>

<h2>Contact Form</h2>

<?php if (!empty($success)): ?>
    <p style="color:green;"><?php echo htmlspecialchars($success); ?></p>
<?php endif; ?>

<?php if (!empty($errors)): ?>
    <ul style="color:red;">
        <?php foreach ($errors as $error): ?>
            <li><?php echo htmlspecialchars($error); ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>

<form method="POST">

    <label>Name:</label><br>
    <input type="text" name="name"
        value="<?php echo htmlspecialchars($old["name"] ?? $name); ?>"><br><br>

    <label>Email:</label><br>
    <input type="text" name="email"
        value="<?php echo htmlspecialchars($old["email"] ?? $email); ?>"><br><br>

    <label>Message:</label><br>
    <textarea name="message"><?php echo htmlspecialchars($old["message"] ?? $message); ?></textarea><br><br>

    <input type="submit" value="Send">
</form>

</body>
</html>