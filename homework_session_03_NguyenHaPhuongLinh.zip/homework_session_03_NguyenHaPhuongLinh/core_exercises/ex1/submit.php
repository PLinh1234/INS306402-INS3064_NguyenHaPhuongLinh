<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $fullname = isset($_POST["fullname"]) ? trim($_POST["fullname"]) : "";
    $email    = isset($_POST["email"]) ? trim($_POST["email"]) : "";
    $message  = isset($_POST["message"]) ? trim($_POST["message"]) : "";

    if ($fullname == "" || $email == "" || $message == "") {
        echo "Error: All fields are required.";
    }
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Error: Invalid email format.";
    }
    else {
        echo "<h3>Thank you for contacting us!</h3>";
        echo "Name: " . htmlspecialchars($fullname) . "<br>";
        echo "Email: " . htmlspecialchars($email) . "<br>";
        echo "Message: " . htmlspecialchars($message);
    }

} else {
    echo "Invalid request.";
}
?>