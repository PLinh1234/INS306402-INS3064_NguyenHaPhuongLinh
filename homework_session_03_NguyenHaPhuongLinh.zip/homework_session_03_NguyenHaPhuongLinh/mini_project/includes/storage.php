<?php

function get_users() {
    $file = __DIR__ . '/../storage.json';

    if (!file_exists($file)) {
        file_put_contents($file, json_encode([]));
    }

    return json_decode(file_get_contents($file), true);
}

function save_users($users) {
    $file = __DIR__ . '/../storage.json';
    file_put_contents($file, json_encode($users, JSON_PRETTY_PRINT));
}