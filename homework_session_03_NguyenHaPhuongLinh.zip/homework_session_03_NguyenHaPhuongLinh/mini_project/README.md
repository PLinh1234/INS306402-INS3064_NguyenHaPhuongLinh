# Mini Project — User Profile System

## Overview

This project is a simple PHP-based User Profile System that integrates:

- Registration with validation
- Login with session management
- Access control protection
- Profile editing (Bio + Avatar upload)
- Secure logout
- Basic security protections (XSS & file validation)

The system uses a JSON file to simulate database storage (no MySQL).

---

## Project Structure

mini_project/
│
├── assets/
│   └── uploads/          (Uploaded avatar images)
│
├── includes/
│   ├── auth.php          (Access control)
│   ├── functions.php     (Helper functions)
│   └── storage.php       (JSON storage logic)
│
├── public/
│   ├── index.php
│   ├── register.php
│   ├── login.php
│   ├── dashboard.php
│   ├── profile.php
│   └── logout.php
│
├── storage.json          (Simulated database)
└── README.md

---

## Features

### 1. Registration System
- Username, Email, Password, Confirm Password
- Password confirmation validation
- Email validation
- Password hashing using password_hash()
- Data saved to storage.json

### 2. Login System
- Credential verification
- Session initialization using session_start()
- Login attempt limit (3 tries)

### 3. Access Control
- profile.php protected
- Redirects unauthenticated users to login.php

### 4. Profile Editing
- Update Bio text
- Upload avatar image
- Allowed file types: JPG, PNG, GIF
- Existing data auto-populated
- Data persists after refresh

### 5. Security Measures
- Password hashing
- XSS protection using htmlspecialchars()
- File type validation
- Session-based authentication
- Secure session destruction on logout

---

## Acceptance Test Checklist

✔ Registration shows error if passwords do not match  
✔ Login blocked after 3 failed attempts  
✔ profile.php redirects when not logged in  
✔ XSS script input does not execute  
✔ .exe or .pdf upload rejected  
✔ Valid image upload works  
✔ Logout visible only when logged in  
✔ Profile data persists after refresh  

---

## How to Run

1. Place the project inside htdocs (XAMPP or MAMP)
2. Start Apache
3. Open in browser:

http://localhost/mini_project/public/index.php

---

INS3064 — Mini Project Submission