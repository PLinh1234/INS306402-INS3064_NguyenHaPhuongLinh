<?php
require '../includes/functions.php';
require '../includes/storage.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];

    if (!$username) $errors[] = "Username required";
    if (!is_valid_email($email)) $errors[] = "Invalid email";
    if (strlen($password) < 6) $errors[] = "Password must be 6+ chars";
    if ($password !== $confirm) $errors[] = "Passwords do not match";

    if (empty($errors)) {
        $users = get_users();

        $users[] = [
            'username' => $username,
            'email' => $email,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'bio' => '',
            'avatar' => ''
        ];

        save_users($users);

        header("Location: login.php");
        exit;
    }
}
?>

<h2>Register</h2>

<?php foreach($errors as $e): ?>
<p style="color:red"><?= $e ?></p>
<?php endforeach; ?>

<form method="POST">
    Username: <input name="username"><br>
    Email: <input name="email"><br>
    Password: <input type="password" name="password"><br>
    Confirm: <input type="password" name="confirm_password"><br>
    <button>Register</button>
</form>