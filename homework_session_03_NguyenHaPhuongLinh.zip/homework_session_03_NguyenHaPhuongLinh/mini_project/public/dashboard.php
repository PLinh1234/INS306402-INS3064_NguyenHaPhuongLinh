<?php
require '../includes/auth.php';
?>

<h2>Dashboard</h2>

Welcome <?= htmlspecialchars($_SESSION['user']['username']) ?><br><br>

<a href="profile.php">Edit Profile</a><br>
<a href="logout.php">Logout</a>