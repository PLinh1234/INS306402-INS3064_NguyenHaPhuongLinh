<?php
require '../includes/auth.php';
require '../includes/functions.php';
require '../includes/storage.php';

$user = $_SESSION['user'];
$users = get_users();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $bio = $_POST['bio'];

    if (!empty($_FILES['avatar']['name'])) {

        $allowed = ['image/jpeg','image/png','image/gif'];

        if (!in_array($_FILES['avatar']['type'], $allowed)) {
            die("Invalid file type.");
        }

        $filename = time() . '_' . $_FILES['avatar']['name'];
        move_uploaded_file($_FILES['avatar']['tmp_name'],
            "../assets/uploads/$filename");

        $user['avatar'] = $filename;
    }

    $user['bio'] = $bio;

    foreach ($users as &$u) {
        if ($u['email'] === $user['email']) {
            $u = $user;
        }
    }

    save_users($users);
    $_SESSION['user'] = $user;
}
?>

<h2>Profile</h2>

<form method="POST" enctype="multipart/form-data">
    Bio:<br>
    <textarea name="bio"><?= e($user['bio']) ?></textarea><br><br>

    Avatar: <input type="file" name="avatar"><br><br>

    <button>Save</button>
</form>

<?php if($user['avatar']): ?>
    <img src="../assets/uploads/<?= e($user['avatar']) ?>" width="150">
<?php endif; ?>

<br><br>
<a href="dashboard.php">Back</a>