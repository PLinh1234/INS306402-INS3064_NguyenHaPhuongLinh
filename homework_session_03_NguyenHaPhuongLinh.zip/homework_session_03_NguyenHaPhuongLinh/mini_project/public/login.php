<?php
session_start();
require '../includes/storage.php';

if (!isset($_SESSION['attempts'])) {
    $_SESSION['attempts'] = 0;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($_SESSION['attempts'] >= 3) {
        die("Too many login attempts.");
    }

    $email = $_POST['email'];
    $password = $_POST['password'];

    $users = get_users();

    foreach ($users as $user) {
        if ($user['email'] === $email && 
            password_verify($password, $user['password'])) {

            $_SESSION['user'] = $user;
            $_SESSION['attempts'] = 0;

            header("Location: dashboard.php");
            exit;
        }
    }

    $_SESSION['attempts']++;
    $errors[] = "Invalid credentials";
}
?>

<h2>Login</h2>

<?php foreach($errors as $e): ?>
<p style="color:red"><?= $e ?></p>
<?php endforeach; ?>

<form method="POST">
    Email: <input name="email"><br>
    Password: <input type="password" name="password"><br>
    <button>Login</button>
</form>