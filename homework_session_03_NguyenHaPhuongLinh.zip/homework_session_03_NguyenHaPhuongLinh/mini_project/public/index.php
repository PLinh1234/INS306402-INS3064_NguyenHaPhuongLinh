<?php
session_start();
?>

<h1>Home</h1>

<?php if(isset($_SESSION['user'])): ?>
    <a href="dashboard.php">Dashboard</a><br>
    <a href="logout.php">Logout</a>
<?php else: ?>
    <a href="register.php">Register</a><br>
    <a href="login.php">Login</a>
<?php endif; ?>